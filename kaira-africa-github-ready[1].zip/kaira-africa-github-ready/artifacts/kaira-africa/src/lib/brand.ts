import logoUrl from '@assets/file_00000000eeb881f4948b1dbbe04abbb2_1785501248542.png';

export const BRAND = {
  name: 'Kaira Africa',
  tagline: 'Know Your Business. Grow Your Business.',
  logoUrl,
} as const;

export { logoUrl };
